#!/usr/bin/env node

 

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*                                                                                                 *
*    Copyright (c) 2023 Evomatic srl                                                              *
*    All rights reserved.                                                                         *
*                                                                                                 *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

 

require('../src/index.js');