const {conversioneStringa} = require('./utils/function'); 

const input = {
    nome:'pippo',
    cognome: '<p></p>', 
    eta: 5
};

const str = 'aashbdjasbdbd @nome e @cognome? asnjdbasdasdbkjans @eta @eta.';

conversioneStringa(str, input);