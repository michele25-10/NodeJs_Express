const conversioneStringa = (stringa, input) => {

    const htmlRegex = new RegExp("<([A-Za-z][A-Za-z0-9]*)\\b[^>]*>(.*?)</\\1>");

    for (const i in input) {
        if (input[i] !== null) {
            if (!htmlRegex.test(input[i])) {
                let stringaReplace = '@' + i;
                if (stringa.includes(stringaReplace)) {
                    stringa = stringa.replaceAll(stringaReplace, input[i]);
                } else {
                    console.log(`Il segnaposto ${i} non è presente nella stringa`);
                }
            } else{
                console.log('Non puoi inserire del codice all\'interno delle variabili');
            }
        } else {
            console.log(`Il campo passato ${i} è null`);
        }
    }
    console.log(stringa);
}

module.exports = {
    conversioneStringa
}